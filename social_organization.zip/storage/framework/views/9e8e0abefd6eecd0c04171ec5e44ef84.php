<?php echo e($publications->links('components.paginator')); ?>


<?php
$class_head_tr = 'sticky z-10 top-10 text-xs leading-6 font-semibold text-black bg-white p-3 border border-collapse';
$class_body_tr = 'py-3 pl-2 pr-2 font-mono text-xs leading-6 bg-white text-gray-900 border
border-collapse';

?>
<div class="grid gap-4 md:grid-cols-1 print:grid-cols-1 rounded-lg mt-3 px-1">
    <table class="w-full">
        <thead>
            <tr class="text-center">
                <th class="<?php echo e($class_head_tr); ?>">Id</th>
                <th class="<?php echo e($class_head_tr); ?>">Title</th>
                <th class="<?php echo e($class_head_tr); ?>">Type</th>
                <th class="<?php echo e($class_head_tr); ?>">Year</th>
                <th class="<?php echo e($class_head_tr); ?>">Writer</th>
                <th class="<?php echo e($class_head_tr); ?>">Link</th>
                <th class="<?php echo e($class_head_tr); ?>">Pdf</th>
                <th class="<?php echo e($class_head_tr); ?>">Status</th>
                <th class="<?php echo e($class_head_tr); ?>">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($publication->id ?? ''); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($publication->title ?? ''); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($publication->type == '1' ? 'Journal' : 'Conference'); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($publication->year ?? ''); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($publication->writer ?? ''); ?></td>
                <td class="<?php echo e($class_body_tr); ?>">
                    <?php if($publication->link ?? ''): ?>
                    <a href="<?php echo e($publication->link ?? '#'); ?>" target="_blank" rel="noopener noreferrer" class="px-3 py-1 bg-green-500 hover:bg-green-400 text-white rounded">
                        Link
                    </a>
                    <?php else: ?>
                        <span class="text-rose-600">Empty</span>
                    <?php endif; ?>
                </td>
                <td class="<?php echo e($class_body_tr); ?>">
                    <?php if($publication->file ?? ''): ?>
                    <a href="<?php echo e(isset($publication->file) ? asset($publication->file): '#'); ?>" target="_blank" rel="noopener noreferrer" class="px-3 py-1 bg-orange-500 hover:bg-orange-400 text-white rounded">
                        Pdf
                    </a>
                    <?php else: ?>
                        <span class="text-rose-600">Empty</span>
                    <?php endif; ?>
                </td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($publication->status == 1 ? 'Actice':'InActive'); ?></td>
            
                <td class="<?php echo e($class_body_tr); ?>">
                    <div class="flex justify-between gap-1">
                        <a href="<?php echo e(route('manage-publications.edit', $publication->id)); ?>"
                            class="edit_publication px-3 py-1 rounded bg-sky-500 hover:bg-blue-400 text-white">
                            Edit
                        </a>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<hr class="my-2 print:hidden">

<?php echo e($publications->links('components.paginator')); ?><?php /**PATH C:\laragon\www\personal_website\resources\views/admin/publication/data.blade.php ENDPATH**/ ?>