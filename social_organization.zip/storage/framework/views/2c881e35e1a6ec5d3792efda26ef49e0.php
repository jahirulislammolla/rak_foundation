<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mx-auto mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if($errors->any()): ?>
                <ul class="bg-yellow-500 text-white p-3 rounded mb-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>

                <div class="card border border-gray-300 shadow-lg rounded-lg">
                    <div class="card-header bg-gray-200 p-4 rounded-t-lg">
                        <div class="text-lg font-semibold flex justify-between items-center">
                            <span>Edit Role</span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
                            <a href="<?php echo e(url('roles')); ?>" class="btn bg-red-500 text-white py-2 px-4 rounded float-right">Back</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <form action="<?php echo e(url('roles/'.$role->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-3">
                                <label for="" class="block text-sm font-medium text-gray-700">Role Name</label>
                                <input type="text" name="name" value="<?php echo e($role->name); ?>" class="form-input mt-1 p-2 border border-gray-600 block w-full rounded-md  shadow-sm focus:ring-blue-500 focus:border-blue-500" />
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn bg-blue-500 text-white py-2 px-4 rounded">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/role-permission/role/edit.blade.php ENDPATH**/ ?>