<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* Sliding Animation */
        .slide-in {
            animation: slideIn 1s ease-out forwards;
        }
    
        .slide-up {
            animation: slideUp 1s ease-in forwards;
        }
    
        @keyframes slideIn {
            0% {
                transform: translateY(50px);
                opacity: 0;
            }
    
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }
    
        @keyframes slideUp {
            0% {
                transform: translateY(-50px);
                opacity: 0;
            }
    
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }
    
        .link-hover {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            transition: all 0.3s ease;
            /* Smooth transition for the hover effect */
        }
    
        @keyframes move-twinkling {
            from {
                background-position: 0 0;
            }
    
            to {
                background-position: -9900px 5100px;
            }
        }
    
        @keyframes move-clouds {
            from {
                background-position: 0 0;
            }
    
            to {
                background-position: 10050px 0;
            }
        }
    
        .background_3d_div {
            position: absolute; 
            top: 0px; 
            left: 0px; 
            z-index: 30; 
            width: 100%; 
            height: 100%; 
            backface-visibility: hidden; 
            transform: translate3d(0px, 43.897px, 0px); 
            visibility: inherit; 
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }
    
        .background_3d_image_div {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/geograpy.jpg')); ?>");
            background-size: cover; 
            background-position: center center; 
            width: 100%; 
            height: 100%; 
            opacity: 1; 
            visibility: inherit; 
            z-index: 20;
        }
    
        #profile {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/pattern-1.png')); ?>");
            background-size: cover; 
            background-position: center center; 
            background-color: #1c404ee0;
            font-size: 16px;
            line-height: 2em;
            font-family: 'Roboto', sans-serif;
        }
    
        /* New Animations */
        .fade-in {
            opacity: 0;
            animation: fadeIn 1s ease-in forwards;
        }
    
        @keyframes fadeIn {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

            /* Rotation Animation */
    .rotate {
        animation: rotate 2s linear infinite;
    }

    @keyframes rotate {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }

    </style>
     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'Home'); ?> <?php $__env->endSlot(); ?>
    <main class="relative w-full p-4 pt-20 lg:pt-20 h-full text-white overflow-hidden justify-center items-center bg-home">

        <section id="biography" class="lg:mb-3 mx-auto z-40 relative">
            <div class="w-full py-12 lg:py-24 animated-background flex items-center">

                <div class="col-span-1 text-white w-full text-lg leading-relaxed pt-1 lg:pt-4 px-3 lg:px-0 slide-in">
                    <h1 class="lg:text-3xl text-2xl font-bold py-2">Md Saifuzzaman, PhD</h1>
                    <h2 class="font-semibold lg:text-xl text-lg py-1">Department of Biology, Faculty of Science, McGill University.</h2>
                    <div class="lg:text-lg text-sm py-2">
                        <a class='py-2 px-4 hover:px-5 text-slate-100 rounded-lg bg-blue-900
                        hover:bg-orange-700 hover:text-white hover:border-orange-700 link-hover fade-in' href="https://www.mcgill.ca/" target="_blank" rel="McGrill University">McGill University</a>
                    </div>
                </div>
            </div>
        </section>
        <div class="slotholder background_3d_div" style="">
            <div class="tp-bgimg defaultimg background_3d_image_div" data-bgcolor="undefined" style="" src="<?php echo e(asset('assets/images/background/image-3.png')); ?>"></div>
        </div>
    </main>
    <div id='profile' class="relative z-20 w-full pt-8 lg:pt-6 px-4 text-white overflow-hidden ">
        <section class="w-full my-2 lg:my-5 mx-auto">
            <div class="w-full py-4 px-3 lg:px-28">
                <div class="grid grid-cols-1 lg:grid-cols-7 justify-between items-start">
                    <div class="text-justify col-span-5 pr-2 lg:pr-10">
                        <strong class="text-gray-200">Dr. Saifuzzaman (Saif)</strong class="text-gray-200"> is a Postdoctoral Researcher at <strong>McGill University</strong>. He holds a PhD degree from the Department of Bioresource Engineering, McGill University, where he investigated machine learning models and AI tools for crop production by integrating proximal soil sensing and remote sensing data. Prior to his work in the Department, he completed two master’s programs – an M.Sc. from Jahangirnagar University, Bangladesh, and MES from Queen’s University, Canada. Working with a large number of international organizations, Md developed cutting-edge geospatial technologies along with satellite- and UAV-based imaging systems for precision farming. He has over eight professional affiliations, and chaired different executive committees and numerous workshops, guest-edited special issues, and reviewed submissions to wide range of scholarly journals. Much of this research has involved collaborating with local and international researchers in environmental science, soil science, computer science, and broader geosciences.
                        <div>
                            <?php echo $__env->make('components.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="w-full col-span-2 px-2 lg:pr-6 slide-up fade-in">
                        <img class="w-full lg:w-80 mt-2 mx-auto lg:mx-0" src="<?php echo e(asset('assets/images/saifuzzaman2.jpg')); ?>" alt="saifuzzaman">
                    </div>
                </div>
                <br />
                <p class="text-justify">

                </p>
            </div>
        </section>
    </div>
    <script>

        // Function to add fade-in animation when elements come into view
        function handleScrollAnimation() {
            const fadeElements = document.querySelectorAll('.fade-in');

            fadeElements.forEach(element => {
                const rect = element.getBoundingClientRect();
                if (rect.top <= window.innerHeight && rect.bottom >= 0) {
                    element.style.opacity = 1;
                    element.classList.add('slide-in');  // Or any other animation class
                }
            });
        }

        // Listen for scroll events
        window.addEventListener('scroll', handleScrollAnimation);

        // Initial check in case elements are already in view
        handleScrollAnimation();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/index.blade.php ENDPATH**/ ?>