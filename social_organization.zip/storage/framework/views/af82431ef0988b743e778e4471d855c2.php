<?php echo e($outreachs->links('components.paginator')); ?>


<?php
$class_head_tr = 'sticky z-10 top-10 text-xs leading-6 font-semibold text-white bg-sky-600 p-3 border border-collapse';
$class_body_tr = 'py-3 pl-2 pr-2 font-mono text-xs leading-6 bg-white text-gray-900 border
border-collapse';

?>
<div class="grid gap-4 md:grid-cols-1 print:grid-cols-1 rounded-lg mt-3 px-1">
    <table class="w-full">
        <thead class="bg-sky-600">
            <tr class="text-center">
                <th class="<?php echo e($class_head_tr); ?>">Id</th>
                <th class="<?php echo e($class_head_tr); ?>">Title</th>
                <th class="<?php echo e($class_head_tr); ?>">Content</th>
                <th class="<?php echo e($class_head_tr); ?>">Priority</th>
                <th class="<?php echo e($class_head_tr); ?>">Status</th>
                <th class="<?php echo e($class_head_tr); ?>">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $outreachs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $outreach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($outreach->id ?? ''); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($outreach->title ?? ''); ?></td>
                <td class="<?php echo e($class_body_tr); ?> text-left"><?php echo $outreach->content ?? ''; ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($outreach->priority ?? ''); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($outreach->status == 1 ? 'Actice':'InActive'); ?></td>
                <td class="<?php echo e($class_body_tr); ?>">
                    <div class="flex justify-between gap-1">
                        <a href="<?php echo e(route('manage-outreachs.edit', $outreach->id)); ?>"
                            class="edit_outreach px-3 py-1 rounded bg-sky-500 hover:bg-blue-400 text-white">
                            Edit
                        </a>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<hr class="my-2 print:hidden">

<?php echo e($outreachs->links('components.paginator')); ?><?php /**PATH C:\laragon\www\personal_website\resources\views/admin/outreach/data.blade.php ENDPATH**/ ?>