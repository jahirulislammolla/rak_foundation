<?php if (isset($component)) { $__componentOriginal533f7a700a8fe65856d7a3def11d79ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal533f7a700a8fe65856d7a3def11d79ea = $attributes; } ?>
<?php $component = App\View\Components\AppLayoutResearch::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout-research'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayoutResearch::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* custom.css */   
        .background_3d_div {
            position: absolute; 
            top: 0px; 
            left: 0px; 
            z-index: 30; 
            width: 100%; 
            height: 100%; 
            backface-visibility: hidden; 
            transform: translate3d(0px, 43.897px, 0px); 
            visibility: inherit; 
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }
    
        .background_3d_image_div {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/research_earth.jpg')); ?>");
            background-size: cover; 
            background-position: center center; 
            width: 100%; 
            height: 100%; 
            opacity: 1; 
            visibility: inherit; 
            z-index: 20;
        }

        #research {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/pattern-3.png')); ?>");
            background-size: cover; 
            background-position: center center; 
            background-color: #13595ada;
            color:white;
            font-size: 17px;
            line-height: 2em;
            font-family: 'Roboto', sans-serif;
        }
        
        #research a {
            transition: color 0.5s ease;
            color: whitesmoke;
        }
        #research a:hover {
            color: #FF6600; /* hover text color */
        }
    

         /* Animation styles */
         .fade-in2 {
            opacity: 0;
            animation: fadeInAnimation ease 2s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }
        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }


        @keyframes fadeIn2 {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .fade-in2-2 {
            animation: fadeIn2 1s ease-in-out forwards;
        }

        iframe {
            @apply absolute top-0 left-0 w-full h-full border-none;
        }
    </style>
     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'RESEARCH OUTREACH'); ?> <?php $__env->endSlot(); ?>

    <main id='research' class="w-full text-lg h-full overflow-hidden bg-gray-200">
        <iframe id="myIframe" class="w-full" style="height: 100vh;" src="https://www.globalmangrovewatch.org/country/BGD?bounds=[[78.27088088530434,17.144246190514764],[102.41334610466873,27.306117782094887]] "></iframe>
    </main>
    <script>
         function setIframeHeight() {
            var iframe = document.getElementById('myIframe');
            iframe.style.height = window.innerHeight + 'px';
        }

        // Set the iframe height when the page loads
        window.onload = setIframeHeight;

        // Adjust the iframe height if the window is resized
        window.onresize = setIframeHeight;
        const background = document.getElementById('background');

        function createLine() {
            const line = document.createElement('div');
            line.className = 'line';
            line.style.height = `${Math.random() * 100 + 50}px`;
            line.style.top = `${Math.random() * 100}vh`;
            line.style.left = `${Math.random() * 100}vw`;
            line.style.animationDuration = `${Math.random() * 10 + 5}s`;
            background.appendChild(line);

            setTimeout(() => {
                background.removeChild(line);
            }, 15000); // Ensure lines are removed after their animation ends
        }

        function createDot() {
            const dot = document.createElement('div');
            dot.className = 'dot';
            dot.style.top = `${Math.random() * 100}vh`;
            dot.style.left = `${Math.random() * 100}vw`;
            dot.style.animationDelay = `${Math.random() * 2}s`;
            background.appendChild(dot);

            setTimeout(() => {
                background.removeChild(dot);
            }, 2000); // Ensure dots are removed after their animation ends
        }

        function init() {
            for (let i = 0; i < 20; i++) {
                createLine();
                createDot();
            }

            setInterval(createLine, 1000);
            setInterval(createDot, 500);
        }

        window.onload = init;
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal533f7a700a8fe65856d7a3def11d79ea)): ?>
<?php $attributes = $__attributesOriginal533f7a700a8fe65856d7a3def11d79ea; ?>
<?php unset($__attributesOriginal533f7a700a8fe65856d7a3def11d79ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal533f7a700a8fe65856d7a3def11d79ea)): ?>
<?php $component = $__componentOriginal533f7a700a8fe65856d7a3def11d79ea; ?>
<?php unset($__componentOriginal533f7a700a8fe65856d7a3def11d79ea); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/research_mangrove_ecosystem.blade.php ENDPATH**/ ?>