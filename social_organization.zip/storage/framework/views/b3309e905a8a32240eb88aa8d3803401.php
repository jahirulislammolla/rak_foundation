<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* custom.css */   
        .background_3d_div {
            position: absolute; 
            top: 0px; 
            left: 0px; 
            z-index: 30; 
            width: 100%; 
            height: 100%; 
            backface-visibility: hidden; 
            transform: translate3d(0px, 43.897px, 0px); 
            visibility: inherit; 
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }
    
        .background_3d_image_div {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/contact-us.png')); ?>");
            background-size: cover; 
            background-position: center center; 
            width: 100%; 
            height: 100%; 
            opacity: 1; 
            visibility: inherit; 
            z-index: 20;
        }

        #contact-details {
            background-position: center center; 
            background-color: #104e6a;
            font-size: 16px;
            line-height: 2em;
            font-family: 'Roboto', sans-serif;
        }
        
        #contact-details a {
            transition: color 0.5s ease;
            color: whitesmoke;
        }
        #contact-details a:hover {
            color: #FF6600; /* hover text color */
        }
    

         /* Animation styles */
         .fade-in {
            opacity: 0;
            animation: fadeInAnimation ease 2s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }
        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
        .toast {
            position: fixed;
            top: 400px;
            right: 20px;
            background-color: #4caf50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: none;
        }
        .toast.error {
            background-color: #f44336;
        }
        </style>

     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'CONTACT'); ?> <?php $__env->endSlot(); ?>
    <section class="relative w-full h-full text-center lg:mb-0 overflow-hidden">
        <div class="relative px-5 py-24 lg:py-52 flex h-full w-full justify-start items-center z-41" 
        >
            <h1 class="text-3xl lg:text-4xl text-black font-semibold border-b-orange-800 fade-in" style="z-index: 42; font-family: 'Roboto', sans-serif; font-size:36px;">CONTACT</h1>
        </div>
        <div class="slotholder background_3d_div" style="">
            <div class="tp-bgimg defaultimg background_3d_image_div" data-bgcolor="undefined" style="" src="<?php echo e(asset('assets/images/background/contact-us.png')); ?>"></div>
        </div>
    </section>
    <section id='contact-details' class="py-5 text-white z-20">
        <div class="container mx-auto px-4">
            <div class="mt-3">
                <div class="w-full grid grid-cols-1 lg:grid-cols-3 gap-2 grid-flow-row lg:grid-flow-col">
                    <div class="col-sapn-1 lg:col-span-2 mb-2">
                        <h1 class="lg:text-xl text-lg font-bold py-2">Md Saifuzzaman, PhD</h1>
                        <h2 class="text-lg py-1">Department of Biology, Faculty of Science
                            , McGill University.</h2>
                        <p class="text-lg py-1">
                            Stewart Biology Building, Penfield Avenue Montreal, QC Canada H3A 1B1
                        </p>
                        <p class="text-lg py-1">
                            <b>Telephone: </b>
                            <a class="text-blue-500" href="tel:+15145609229">+1 514 560 9229</a>
                        </p>
                        <p class="text-lg py-1">
                            <b>Email: </b>
                            <a class="text-blue-500" href="mailto:md.saifuzzaman@mail.mcgill.ca">md.saifuzzaman@mail.mcgill.ca</a> or 
                            <a class="text-blue-500" href="mailto:m.saifuzzaman@gmail.com">m.saifuzzaman@gmail.com</a>
                        </p>
                        <div>
                            <?php echo $__env->make('components.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="col-span-1 mb-2">
                        <img class="w-full rounded-lg lg:float-right lg:ml-10 mx-auto lg:mx-0 fade-in"  src="<?php echo e(asset( 'assets/images/logo/contact_me.jpg' )); ?>" alt="contact">
                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <main class="w-full p-4 h-full text-white overflow-hidden bg-gray-200">
        <section class="py-5 bg-gray-100 border-t border-b border-gray-200">
            <div class="container mx-auto px-4">
                <div class="text-center">
                    <h3 class="text-2xl text-orange-600 font-semibold">Get In <span class="text-blue-500">Touch</span></h3>
                    <p class="text-gray-600 mt-2">Please fill out the following form and we will get back to you shortly.</p>
                </div>
                <div class="mt-3">
                    <div class="w-full grid grid-cols-1 lg:grid-cols-2 gap-2 grid-flow-row lg:grid-flow-col">
                        <div class="col-span-1 mb-2">
                            <img class="w-72 lg:w-96 rounded-lg lg:float-right lg:mr-40 lg:mt-4 mx-auto lg:mx-0 fade-in"  src="<?php echo e(asset( 'assets/images/logo/smartphone.svg' )); ?>" alt="contact">
                        </div>
                        <div class="col-span-1 mb-2">
                            <form action="<?php echo e(route('message.store')); ?>" method="POST" class="space-y-4">
                                <?php echo csrf_field(); ?>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label for="fullname" class="block text-gray-700">Your Name</label>
                                        <input class="form-input mt-1 block w-full bg-gray-200 border border-gray-300 rounded py-2 px-3 text-gray-700" type="text"  name="fullname" id="fullname" placeholder="Name...">
                                    </div>
                                    <div>
                                        <label for="emailaddress" class="block text-gray-700">Your Email</label>
                                        <input class="form-input mt-1 block w-full bg-gray-200 border border-gray-300 rounded py-2 px-3 text-gray-700" type="email" name="email" required id="emailaddress" placeholder="Enter your email...">
                                    </div>
                                </div>
                
                                <div>
                                    <label for="subject" class="block text-gray-700">Your Subject</label>
                                    <input class="form-input mt-1 block w-full bg-gray-200 border border-gray-300 rounded py-2 px-3 text-gray-700" type="text" name="subject" id="subject" placeholder="Enter subject...">
                                </div>
                
                                <div>
                                    <label for="comments" class="block text-gray-700">Message</label>
                                    <textarea id="comments" rows="4" class="form-textarea mt-1 block w-full bg-gray-200 border border-gray-300 rounded py-2 px-3 text-gray-700" name='message' placeholder="Type your message here..."></textarea>
                                </div>
                
                                <div class="text-right">
                                    <button class="btn bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Send a Message 
                                        <i class="mdi mdi-telegram ml-1"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        
    </main>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        $(document).ready(function () {
            $('form').on('submit', function (event) {
                event.preventDefault(); // Prevent default form submission
                
                const formData = {
                    fullname: $('#fullname').val(),
                    email: $('#emailaddress').val(),
                    subject: $('#subject').val(),
                    message: $('#comments').val(),
                    _token: "<?php echo e(csrf_token()); ?>" // Add CSRF token
                };

                $.ajax({
                    url: "<?php echo e(route('message.store')); ?>", // Laravel route for storing the message
                    type: "POST",
                    data: formData,
                    success: function (response) {
                        toastr.success('Message sent successfully. Thank You!', 'Success', {
                            timeOut: 3000, // 3 seconds
                            progressBar: true,
                        });
                        
                        $('form')[0].reset(); // Reset the form
                    },
                    error: function (xhr, status, error) {
                        toastr.error('An error occurred while sending the message.', 'Error', {
                            timeOut: 3000,
                            progressBar: true,
                        });
                    }
                });
            });
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/contact.blade.php ENDPATH**/ ?>