<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mx-auto mt-5">
        <a href="<?php echo e(url('roles')); ?>" class="btn bg-blue-500 text-white py-2 px-4 rounded mx-1">Roles</a>
        <a href="<?php echo e(url('permissions')); ?>" class="btn bg-blue-400 text-white py-2 px-4 rounded mx-1">Permissions</a>
        <a href="<?php echo e(url('users')); ?>" class="btn bg-yellow-500 text-white py-2 px-4 rounded mx-1">Users</a>
    </div>

    <div class="container mx-auto mt-2">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="alert alert-success bg-green-500 text-white p-2 rounded"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card mt-3 border border-gray-300 shadow-lg rounded-lg">
                    <div class="card-header bg-gray-200 p-3 rounded-t-lg">
                        <div class="text-lg font-semibold flex justify-between items-center">
                            <span>Users</span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
                            <a href="<?php echo e(url('users/create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded float-right">Add User</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body p-4">

                        <table class="table-auto w-full text-left border-collapse">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="border-b-2 p-2">Id</th>
                                    <th class="border-b-2 p-2">Name</th>
                                    <th class="border-b-2 p-2">Email</th>
                                    <th class="border-b-2 p-2">Roles</th>
                                    <th class="border-b-2 p-2">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border-b p-2"><?php echo e($user->id); ?></td>
                                    <td class="border-b p-2"><?php echo e($user->name); ?></td>
                                    <td class="border-b p-2"><?php echo e($user->email); ?></td>
                                    <td class="border-b p-2">
                                        <?php if(!empty($user->getRoleNames())): ?>
                                            <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="bg-blue-500 text-white py-1 px-2 rounded mx-1"><?php echo e($rolename); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="border-b p-2">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update user')): ?>
                                        <a href="<?php echo e(url('users/'.$user->id.'/edit')); ?>" class="btn bg-green-500 text-white py-1 px-3 rounded">Edit</a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete user')): ?>
                                        <a href="<?php echo e(url('users/'.$user->id.'/delete')); ?>" onclick="return confirm('Are you sure delete this user?');" class="btn bg-red-500 text-white py-1 px-3 rounded mx-2">Delete</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/role-permission/user/index.blade.php ENDPATH**/ ?>