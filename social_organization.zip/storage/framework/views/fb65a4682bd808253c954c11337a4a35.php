<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* custom.css */   
        .background_3d_div {
            position: absolute; 
            top: 0px; 
            left: 0px; 
            z-index: 30; 
            width: 100%; 
            height: 100%; 
            backface-visibility: hidden; 
            transform: translate3d(0px, 43.897px, 0px); 
            visibility: inherit; 
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }
    
        .background_3d_image_div {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/mentorship.jpg')); ?>");
            background-size: cover; 
            background-position: center center; 
            width: 100%; 
            height: 100%; 
            opacity: 1; 
            visibility: inherit; 
            z-index: 20;
        }

        #research {
            font-size: 17px;
            line-height: 2em;
            font-family: 'Roboto', sans-serif;
        }
        
        #research a {
            transition: color 0.5s ease;
            color: whitesmoke;
        }

        .border_class{
            border-top: 1px solid gray;
            margin: 10px 0px 20px 0px;
        }
        #research a:hover {
            color: #FF6600; /* hover text color */
        }
    

         /* Animation styles */
         .fade-in2 {
            opacity: 0;
            animation: fadeInAnimation ease 2s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }
        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }


        @keyframes fadeIn2 {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        .fade-in2-2 {
            animation: fadeIn2 1s ease-in-out forwards;
        }
    </style>
     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'LEADERSHIP'); ?> <?php $__env->endSlot(); ?>
    <section class="relative w-full h-full text-center  lg:mb-0 overflow-hidden">
        <div class="relative px-5 py-24 lg:py-52 flex h-full w-full justify-start items-center z-41" 
        >
            <h1 class="text-3xl lg:text-4xl text-white font-semibold border-b-orange-800 fade-in" style="z-index: 42; font-family: 'Roboto', sans-serif; font-size:36px;">MENTORSHIP</h1>
        </div>
        <div class="slotholder background_3d_div" style="">
            <div class="tp-bgimg defaultimg background_3d_image_div" data-bgcolor="undefined" style="" src="<?php echo e(asset('assets/images/background/leadership.jpg')); ?>"></div>
        </div>
    </section>
    <?php
        $types =[
            '1' => 'McGill University',
            '2' => 'Jahangirnagar University'
        ]
    ?>
    <main id='research' class="w-full py-4 lg:py-4 px-8 lg:px-48 text-lg h-full overflow-hidden bg-gray-200">
        <div style="font-size: 16px;" class="space-y-6">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <h1 class="text-3xl font-bold mt-10 mb-6" style="color: #21211c;"><?php echo e($type); ?></h1>
                <?php $__currentLoopData = $mentorships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentorship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key == $mentorship->type): ?>
                    <div class="mt-5">
                        <span class="bg-blue-500 text-white px-4 py-2 rounded-sm mr-4">
                            <?php echo e($mentorship->title); ?>

                        </span>
                        <div class="bg-white ml-2 pt-3 pb-2 pl-3 shadow-sm shadow-slate-400  rounded-sm max-w-4xl" style="line-height: 1.8rem;">
                        <?php echo $mentorship->content; ?>

                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/research_mentorship.blade.php ENDPATH**/ ?>