<style>
    /* General transition for navbar links */
    #nav-link a, #nav-content a {
        transition: background-color 0.9s ease, color 0.7s ease;
    }
    #nav-link a:hover, #nav-content a:hover {
        background-color: #ff6600ee; /* hover background color */
        color: white; /* hover text color */
    }

    /* Transition for footer links */
    footer a {
        transition: color 1s ease;
    }
    footer a:hover {
        color: #FF6600; /* hover text color */
    }

    /* Initial state for sliding transition */
    .group-hover\:block,
    .group2-hover\:inline-block {
        display: none; /* initial position for sliding effect */
    }

    /* Hover state for sliding transition */
    .group:hover .group-hover\:block,
    .group2:hover .group2-hover\:inline-block {
        display: block;
        animation: visible .6s; /* slide in effect */
    }
    @keyframes visible {
        from {
        opacity: 0;
        transform: translateY(-12px);
        }
        to {
        opacity: 1;
        transform: translateY(0);
        }
    }


    /* Custom styling for active links */
    .active {
        color: rgb(6, 163, 220);
    }

</style>
<header id='header' class="fixed w-full top-0 z-50 bg-white">
    <nav class="container mx-auto px-6 py-3 lg:py-1">
        <div class="flex justify-between items-center">
            <div>
                <a href="/" class="text-2xl font-bold text-black lg:text-3xl">
                    <img class="w-12 sm:w-16 lg:w-16 text-center" src="<?php echo e(asset('assets/images/logo/saif.png')); ?>" alt="logo">
                </a>
            </div>
            <div class="lg:hidden">
                <button id="nav-toggle" class="text-black focus:outline-none">
                    <!-- Open Button SVG -->
                    <svg id="open-icon" class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                    <!-- Close Button SVG (initially hidden) -->
                    <svg id="close-icon" class="h-6 w-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div id='nav-link' class="hidden lg:flex lg:items-center text-sm lg:text-base">
                <ul id="menu" class="hidden relative md:flex space-x-4">
                    <li class="relative group">
                        <a href="/" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 hover:shadow-xl rounded-lg">Home</a>
                    </li>
                    <li class="relative group">
                        <a href="/profile" class="text-black py-2 px-2 flex items-center hover:shadow-xl rounded-lg">
                            About
                            <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </a>
                        <ul class="absolute left-0 hidden group-hover:block bg-white w-80">
                            <li><a href="/education" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Education</a></li>
                            <li><a href="/profile" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Profile</a></li>
                            <li><a href="/professional-affiliation-service" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Professional Affiliations & Services</a></li>
                        </ul>
                    </li>
                    <li class="relative group">
                        <a href="#" class="text-black py-2 px-2 flex items-center hover:shadow-xl rounded-lg">
                            Research
                            <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </a>
                        <ul class="absolute sub-menu left-0 hidden group-hover:block bg-white w-52">
                            <li class="relative group2">
                                <a href="#" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Publications</a>
                                <ul class="absolute top-0 left-52 hidden group2-hover:inline-block bg-white w-52" style="border-left: 1px solid rgba(0, 0, 0, 0.399);">
                                    <li><a href="/publication-journal" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Journal</a></li>
                                    <li><a href="/publication-conference" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Conference</a></li>
                                </ul>  
                            </li>
                            <li><a href="/award-funds" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Award & Funds</a></li>
                            <li><a href="/research-mentorship" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Research Mentorship</a></li>
                            <li><a href="/research-outreach" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Research Outreach</a></li>
                        </ul>
                    </li>
                    <li class="relative group">
                        <a href="/research-highlights" class="p-2 text-black flex items-center hover:shadow-xl rounded-lg">Research Highlights
                            <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                            </svg>
                        </a>
                        <ul class="absolute left-0 hidden group-hover:block bg-white w-60">
                            <li><a href="/research-alfalfa-story-map" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Alfalfa Story Map</a></li>
                            <li><a href="/research-alfalfa-winter-data" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Alfalfa Winter Data</a></li>
                            <li><a href="/research-mangrove-ecosystem" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Mangrove Ecosystem</a></li>
                        </ul>    
                    </li>
                    <li class="relative group">
                        <a href="/teaching" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 rounded-lg">Teaching</a>
                    </li>
                    <li class="relative group">
                        <a href="/leadership" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 rounded-lg">Leadership</a>
                    </li>
                    <li class="relative group">
                        <a href="/contact" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 rounded-lg">Contact</a>
                    </li>
                    <li class="relative group">
                        <!-- Check if the user is authenticated -->
                        <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 rounded-lg">Dashboard</a>
                        <?php endif; ?>
                                           
                    </li>
                </ul>
            </div>
        </div>
        <div id="nav-content" class="hidden justify-end lg:hidden bg-slate-200 mt-2">
            <ul class="space-y-3">
                <li>
                    <a href="/" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20  lg:mt-0 lg:ml-4">Home</a>
                </li>
                <li class="relative group">
                    <a href="/profile" class="text-black py-2 px-4 flex items-center">
                        About
                        <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </a>
                    <ul class="left-0 hidden group-hover:block bg-slate-200">
                        <li><a href="/education" class="block px-6 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Education</a></li>
                        <li><a href="/profile" class="block px-6 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Profile</a></li>
                        <li><a href="/professional-affiliation-service" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Professional Affiliations & Services</a></li>
                    </ul>
                </li>
                <li class="relative group">
                    <a href="#" class="text-black py-2 px-4 flex items-center hover:shadow-xl">
                        Research
                        <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </a>
                    <ul class="left-0 hidden group-hover:block bg-slate-200">
                        <li><a href="/award-funds" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Award & Funds</a></li>
                        <li><a href="/research-mentorship" class="block px-6 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Research Mentorship</a></li>
                        <li><a href="/profile" class="block px-6 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Profile</a></li>
                        <li><a href="/research-outreach" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20">Research Outreach</a></li>
                    </ul>
                </li>
                <li class="relative group">
                    <a href="/research-highlights" class="py-2 px-4 text-black flex items-center hover:shadow-xl">Research Highlights
                        <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </a>
                    <ul class="left-0 hidden group-hover:block bg-slate-200">
                        <li><a href="/research-alfalfa-story-map" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Alfalfa Story Map</a></li>
                        <li><a href="/research-alfalfa-winter-data" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Alfalfa Winter Data</a></li>
                        <li><a href="/research-mangrove-ecosystem" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Mangrove Ecosystem</a></li>
                    </ul>    
                </li>
                <li class="relative group">
                    <a href="#" class="text-black py-2 px-4 flex items-center hover:shadow-xl">
                        Publications
                        <svg class="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </a>
                    <ul class="left-0 hidden group-hover:block bg-slate-200">
                        <li><a href="/publication-journal" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Journal</a></li>
                        <li><a href="/publication-conference" class="block px-5 py-2 text-black hover:text-orange-600 hover:bg-orange-600/5">Conference</a></li>
                    </ul>
                </li>
                <li class="relative group">
                    <a href="/teaching" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 ">Teaching</a>
                </li>
                <li class="relative group">
                    <a href="/leadership" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 ">Leadership</a>
                </li>
                <li class="relative group">
                    <a href="/contact" class="block px-4 py-2 text-black hover:text-orange-600 hover:bg-orange-600/20 ">Contact</a>
                </li>
            </ul>
        </div>
    </nav>
</header><?php /**PATH C:\laragon\www\personal_website\resources\views/components/header.blade.php ENDPATH**/ ?>