<?php echo e($messages->links('components.paginator')); ?>


<?php
$class_head_tr = 'sticky z-10 top-10 text-xs leading-6 font-semibold text-white bg-sky-600 p-3 border border-collapse';
$class_body_tr = 'py-3 pl-2 pr-2 font-mono text-xs leading-6 bg-white text-gray-900 border border-collapse';
?>

<div class="grid gap-4 md:grid-cols-1 print:grid-cols-1 rounded-lg mt-3 px-1">
    <table class="w-full">
        <thead class="">
            <tr class="text-center">
                <th class="<?php echo e($class_head_tr); ?>">Name</th>
                <th class="<?php echo e($class_head_tr); ?>">Email</th>
                <th class="<?php echo e($class_head_tr); ?>">Subject</th>
                <th class="<?php echo e($class_head_tr); ?>">Message</th>
                <th class="<?php echo e($class_head_tr); ?>">Date</th>
                <th class="<?php echo e($class_head_tr); ?>">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($message->fullname); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($message->email); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($message->subject); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($message->message); ?></td>
                <td class="<?php echo e($class_body_tr); ?>"><?php echo e($message->created_at->format('d M Y')); ?></td>
                <td class="<?php echo e($class_body_tr); ?>">
                    <div class="flex justify-center gap-1">
                        <form action="<?php echo e(route('message.delete', $message->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this item?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="edit_message px-3 py-1 rounded bg-rose-500 hover:bg-rose-400 text-white">
                                Delete
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<hr class="my-2 print:hidden">

<?php echo e($messages->links('components.paginator')); ?>

<?php /**PATH C:\laragon\www\personal_website\resources\views/admin/message/data.blade.php ENDPATH**/ ?>