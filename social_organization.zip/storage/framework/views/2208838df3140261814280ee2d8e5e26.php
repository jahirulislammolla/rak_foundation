<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<ul class="grow text-gray-700 overflow-y-auto px-2 print:hidden grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('dashboard')); ?>"
                class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == 'admin' ? 'text-sky-700' : ''); ?>">
                <i class="w-5 text-center icon-home"></i>
                <span class="grow menu__title">Dashboard</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a onclick="submenuToggle(this)" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="w-5 text-center icon-people"></i>
                <span class="grow menu__title">User</span>
                <i class="w-5 text-center icon-arrow-down"></i>
            </a>
            <ul class="hidden pl-2 py-1">
                <li class="pl-2 font-semibold">
                    <a href="<?php echo e(url('users')); ?>"
                        class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == 'user' ? 'text-sky-700' : ''); ?>">
                        <i class="w-5 text-center icon-people"></i>
                        <span class="grow menu__title">User List</span>
                    </a>
                </li>
                <li class="pl-2 font-semibold">
                    <a href="<?php echo e(url('users/create')); ?>"
                        class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == 'user/create' ? 'text-sky-700' : ''); ?>">
                        <i class="w-5 text-center icon-plus"></i>
                        <span class="grow menu__title">Add User</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a onclick="submenuToggle(this)" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="w-5 text-center icon-people"></i>
                <span class="grow menu__title">Roles</span>
                <i class="w-5 text-center icon-arrow-down"></i>
            </a>
            <ul class="hidden pl-2 py-1">
                <li class="pl-2 font-semibold">
                    <a href="<?php echo e(url('roles')); ?>"
                        class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == 'roles' ? 'text-sky-700' : ''); ?>">
                        <i class="w-5 text-center icon-people"></i>
                        <span class="grow menu__title">Role List</span>
                    </a>
                </li>
                <li class="pl-2 font-semibold">
                    <a href="<?php echo e(url('roles/create')); ?>"
                        class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == 'roles/create' ? 'text-sky-700' : ''); ?>">
                        <i class="w-5 text-center icon-plus"></i>
                        <span class="grow menu__title">Add Role</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a onclick="submenuToggle(this)" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="w-5 text-center icon-people"></i>
                <span class="grow menu__title">Permissions</span>
                <i class="w-5 text-center icon-arrow-down"></i>
            </a>
            <ul class="hidden pl-2 py-1">
                <li class="pl-2 font-semibold">
                    <a href="<?php echo e(url('permissions')); ?>"
                        class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == 'permissions' ? 'text-sky-700' : ''); ?>">
                        <i class="w-5 text-center icon-people"></i>
                        <span class="grow menu__title">Permission List</span>
                    </a>
                </li>
                <li class="pl-2 font-semibold">
                    <a href="<?php echo e(url('permissions/create')); ?>"
                        class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == 'permissions/create' ? 'text-sky-700' : ''); ?>">
                        <i class="w-5 text-center icon-plus"></i>
                        <span class="grow menu__title">Add Permission</span>
                    </a>
                </li>
            </ul>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-publications')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-book w-5 text-center"></i>
                <span class="grow menu__title">Publications List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-profiles')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-user w-5 text-center"></i>
                <span class="grow menu__title">Profile List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-awards')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-trophy w-5 text-center"></i>
                <span class="grow menu__title">Award List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-educations')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-graduation-cap w-5 text-center"></i>
                <span class="grow menu__title">Education List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-leaderships')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-users w-5 text-center"></i>
                <span class="grow menu__title">Leadership List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-mentorships')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-hands-helping w-5 text-center"></i>
                <span class="grow menu__title">Mentorship List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-outreachs')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-bullhorn w-5 text-center"></i>
                <span class="grow menu__title">Outreach List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-teachings')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-chalkboard-teacher w-5 text-center"></i>
                <span class="grow menu__title">Teaching List</span>
            </a>
        </div>
    </li>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-professional-services')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-briefcase w-5 text-center"></i>
                <span class="grow menu__title">Professional Affiliation List</span>
            </a>
        </div>
    </li>
    <li class="pl-2 font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(url('manage-messages')); ?>" class="h-8 flex items-center justify-between gap-2 cursor-pointer">
                <i class="fas fa-envelope w-5 text-center"></i>
                <span class="grow menu__title">Message List</span>
            </a>
        </div>
    </li>

    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($menu->permission)): ?>
    <li class="font-semibold">
        <div class="p-3 border border-dashed bg-sky-300">
            <a href="<?php echo e(count($menu->submenu) ? '#' : url($menu->url)); ?>" onclick="submenuToggle(this)"
                class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::is($menu->url . '*') ? 'text-sky-700' : ''); ?>">
                <i class="w-5 text-center <?php echo e($menu->icon); ?>"></i>
                <span class="grow menu__title"><?php echo e($menu->title); ?></span>
                <?php if(count($menu->submenu)): ?>
                <i class="w-5 text-center icon-arrow-down"></i>
                <?php endif; ?>
            </a>
            <?php if(count($menu->submenu)): ?>
            <ul class="hidden pl-2 py-1">
                <?php $__currentLoopData = $menu->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check($submenu->permission)): ?>
                <li class="pl-2 font-semibold">
                    <a href="<?php echo e(count($submenu->thirdmenu) ? '#' : url($submenu->url)); ?>"
                        onclick="submenuToggle(this)"
                        class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == $submenu->url ? 'text-sky-700' : ''); ?>">
                        <i class="w-5 text-center <?php echo e($submenu->icon); ?>"></i>
                        <span class="grow menu__title"><?php echo e($submenu->title); ?></span>
                        <?php if(count($submenu->thirdmenu)): ?>
                        <i class="w-5 text-center icon-arrow-down"></i>
                        <?php endif; ?>
                    </a>
                    <?php if(count($submenu->thirdmenu)): ?>
                    <ul class="hidden pl-2 py-1">
                        <?php $__currentLoopData = $submenu->thirdmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thirdmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="pl-2 font-semibold">
                            <a href="<?php echo e(url($thirdmenu->url)); ?>"
                                class="h-8 flex items-center justify-between gap-2 cursor-pointer <?php echo e(Request::path() == $thirdmenu->url ? 'text-sky-700' : ''); ?>">
                                <i class="w-5 text-center <?php echo e($submenu->icon); ?>"></i>
                                <span class="grow menu__title"><?php echo e($thirdmenu->title); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </li>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\personal_website\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>