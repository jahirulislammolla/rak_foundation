<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* custom.css */   
        .background_3d_div {
            position: absolute; 
            top: 0px; 
            left: 0px; 
            z-index: 30; 
            width: 100%; 
            height: 100%; 
            backface-visibility: hidden; 
            transform: translate3d(0px, 43.897px, 0px); 
            visibility: inherit; 
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }
    
        .background_3d_image_div {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/education.jpg')); ?>");
            background-size: cover; 
            background-position: center center; 
            width: 100%; 
            height: 100%; 
            opacity: 1; 
            visibility: inherit; 
            z-index: 20;
        }

        #teaching-bangladesh {
            background-position: center center;
            font-size: 17px;
            line-height: 2em;
            font-family: 'Roboto', sans-serif;
        }

        #teaching-bangladesh a {
            transition: color 0.5s ease;
            color: rgba(56, 167, 8, 0.89);
        }

        #teaching-bangladesh a:hover {
            color: #FF6600;
            /* hover text color */
        }

        #teaching-canada {
            background-position: center center;
            font-size: 17px;
            font-family: 'Roboto', sans-serif;
        }
        #education a:hover {
            color: #FF6600; /* hover text color */
        }
    


        @keyframes text-animation {
            0% { opacity: 0; transform: translateY(-20px); }
            10%, 90% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(20px); }
        }

         /* Animation styles */
         .fade-in {
            opacity: 0;
            animation: fadeInAnimation ease 2s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }
        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
        .border_class{
            border-top: 1px solid gray;
            padding-top: 1px;
            padding-bottom: 15px;
        }
        a {
            transition: color 0.5s ease;
            color: rgb(2, 139, 185);
        }
        a:hover {
            color: #FF6600; /* hover text color */
        }
    </style>
     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'education'); ?> <?php $__env->endSlot(); ?>
    <section class="relative w-full h-full text-center lg:mb-0 overflow-hidden">
        <div class="relative px-5 py-24 lg:py-52 flex h-full w-full justify-start items-center z-41" 
        >
            <h1 class="text-3xl lg:text-4xl text-white font-semibold border-b-orange-800 fade-in" style="z-index: 42; font-family: 'Roboto', sans-serif; font-size:36px;">EDUCATION</h1>
        </div>
        <div class="slotholder background_3d_div" style="">
            <div class="tp-bgimg defaultimg background_3d_image_div" data-bgcolor="undefined" style="" src="<?php echo e(asset('assets/images/background/profile.jpg')); ?>"></div>
        </div>
    </section>
    <!-- Research and Professional Profile Section -->
    <main id='teaching-canada' class="w-full py-4 text-black lg:py-10 px-8 lg:px-48 text-lg h-full overflow-hidden bg-gray-200">
        <div class="list-disc space-y-8 animate-text">
            <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="animate-text ">
                <span class="text-lg font-semibold bg-orange-600 text-white py-2 px-2 rounded-sm"><?php echo e($education->title); ?></span>
                <div class="bg-white ml-2 pt-3 pb-2 pl-3 shadow-sm shadow-slate-400  rounded-sm max-w-2xl">
                    <?php echo $education->content; ?>

                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/education.blade.php ENDPATH**/ ?>