<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* custom.css */   
        .background_3d_div {
            position: absolute; 
            top: 0px; 
            left: 0px; 
            z-index: 30; 
            width: 100%; 
            height: 100%; 
            backface-visibility: hidden; 
            transform: translate3d(0px, 43.897px, 0px); 
            visibility: inherit; 
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }
    
        .background_3d_image_div {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/leadership.jpg')); ?>");
            background-size: cover; 
            background-position: center center; 
            width: 100%; 
            height: 100%; 
            opacity: 1; 
            visibility: inherit; 
            z-index: 20;
        }

        #leadership-department {

            font-size: 17px;
            line-height: 2em;
            font-family: 'Roboto', sans-serif;
        }
        #leadership-social {
            background-repeat: no-repeat; 
            font-size: 17px;
            line-height: 2em;
            font-family: 'Roboto', sans-serif;
        }
    
    

         /* Animation styles */
         .fade-in {
            opacity: 0;
            animation: fadeInAnimation ease 2s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }
        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
        .border_class{
            border-top: 1px solid gray;
            margin: 10px 0px 20px 0px;
        }
        @keyframes text-animation {
            0% { opacity: 0; transform: translateY(-20px); }
            10%, 90% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(20px); }
        }
    </style>
     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'LEADERSHIP'); ?> <?php $__env->endSlot(); ?>
    <section class="relative w-full h-full text-center  lg:mb-0 overflow-hidden">
        <div class="relative px-5 py-24 lg:py-52 flex h-full w-full justify-start items-center z-41" 
        >
            <h1 class="text-3xl lg:text-4xl text-sky-900 font-semibold border-b-orange-800 fade-in" style="z-index: 42; font-family: 'Roboto', sans-serif; font-size:36px;">LEADERSHIP</h1>
        </div>
        <div class="slotholder background_3d_div" style="">
            <div class="tp-bgimg defaultimg background_3d_image_div" data-bgcolor="undefined" style="" src="<?php echo e(asset('assets/images/background/leadership.jpg')); ?>"></div>
        </div>
    </section>
    <main id='leadership-department' class="w-full py-3 lg:py-14 px-8 lg:px-48 text-lg h-full overflow-hidden bg-gray-200">
      <div style="font-size: 16px;" class="space-y-6">
        <?php $__currentLoopData = $leaderships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leadership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <span class="bg-violet-900 font-semibold text-white px-4 py-2 rounded-sm mr-4">
             <?php echo e($leadership->title); ?>

            </span>
            <div class="bg-white ml-2 pt-3 pb-2 pl-3 pr-2 shadow-sm shadow-slate-400  rounded-sm max-w-5xl" style="line-height: 1.8rem;">
              <?php echo $leadership->content; ?>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>  
   </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/leadership.blade.php ENDPATH**/ ?>