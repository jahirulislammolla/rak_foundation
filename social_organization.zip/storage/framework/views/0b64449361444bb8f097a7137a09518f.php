<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mx-auto mt-5">
        <a href="<?php echo e(url('roles')); ?>" class="btn btn-primary bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mx-1">Roles</a>
        <a href="<?php echo e(url('permissions')); ?>" class="btn btn-info bg-blue-400 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mx-1">Permissions</a>
        <a href="<?php echo e(url('users')); ?>" class="btn btn-warning bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded mx-1">Users</a>
    </div>

    <div class="container mx-auto mt-2">
        <div class="row">
            <div class="w-full">

                <?php if(session('status')): ?>
                    <div class="alert alert-success bg-green-100 border-l-4 border-green-500 text-green-700 p-4"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card bg-white shadow-md rounded mt-3">
                    <div class="card-header px-6 py-3 border-b border-gray-200">
                        <div class="text-lg font-semibold flex justify-between items-center">
                            <span>Permissions</span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create permission')): ?>
                            <a href="<?php echo e(url('permissions/create')); ?>" class="btn btn-primary bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded float-right">Add Permission</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body p-6">

                        <table class="table-auto w-full text-left border-collapse">
                            <thead>
                                <tr>
                                    <th class="border-b px-4 py-2">Id</th>
                                    <th class="border-b px-4 py-2">Name</th>
                                    <th class="border-b px-4 py-2 w-1/3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border-t px-4 py-2"><?php echo e($permission->id); ?></td>
                                    <td class="border-t px-4 py-2"><?php echo e($permission->name); ?></td>
                                    <td class="border-t px-4 py-2">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update permission')): ?>
                                        <a href="<?php echo e(url('permissions/'.$permission->id.'/edit')); ?>" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">Edit</a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete permission')): ?>
                                        <a href="<?php echo e(url('permissions/'.$permission->id.'/delete')); ?>" onclick="return confirm('Are you sure delete this permission?');" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded mx-2">Delete</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/role-permission/permission/index.blade.php ENDPATH**/ ?>