
<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mx-auto mt-5">
        <a href="<?php echo e(url('roles')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded mx-1">Roles</a>
        <a href="<?php echo e(url('permissions')); ?>" class="bg-blue-400 text-white px-4 py-2 rounded mx-1">Permissions</a>
        <a href="<?php echo e(url('users')); ?>" class="bg-yellow-500 text-white px-4 py-2 rounded mx-1">Users</a>
    </div>

    <div class="container mx-auto mt-2">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('status')): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="card bg-white shadow-md rounded mt-3">
                    <div class="card-header border-b border-gray-200 px-4 py-3">
                        <div class="text-lg font-semibold flex justify-between items-center">
                            <span>Roles</span>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
                            <a href="<?php echo e(url('roles/create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded float-right">Add Role</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body px-4 py-2">

                        <table class="min-w-full bg-white">
                            <thead>
                                <tr>
                                    <th class="py-2 px-4 border-b">Id</th>
                                    <th class="py-2 px-4 border-b">Name</th>
                                    <th class="py-2 px-4 border-b" style="width: 40%;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2 px-4 border-b"><?php echo e($role->id); ?></td>
                                    <td class="py-2 px-4 border-b"><?php echo e($role->name); ?></td>
                                    <td class="py-2 px-4 border-b">
                                        <a href="<?php echo e(url('roles/'.$role->id.'/give-permissions')); ?>" class="bg-yellow-500 text-white px-4 py-2 rounded">Add / Edit Role Permission</a>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update role')): ?>
                                        <a href="<?php echo e(url('roles/'.$role->id.'/edit')); ?>" class="bg-green-500 text-white px-4 py-2 rounded ml-2">Edit</a>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                                        <a href="<?php echo e(url('roles/'.$role->id.'/delete')); ?>" onclick="return confirm('Are you sure delete this role?');" class="bg-red-500 text-white px-4 py-2 rounded ml-2">Delete</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\personal_website\resources\views/role-permission/role/index.blade.php ENDPATH**/ ?>