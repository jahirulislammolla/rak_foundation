<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* custom.css */   
        .background_3d_div {
            position: absolute; 
            top: 0px; 
            left: 0px; 
            z-index: 30; 
            width: 100%; 
            height: 100%; 
            backface-visibility: hidden; 
            transform: translate3d(0px, 43.897px, 0px); 
            visibility: inherit; 
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }
    
        .background_3d_image_div {
            background-repeat: no-repeat; 
            background-image: url("<?php echo e(asset('assets/images/background/publications.jpg')); ?>");
            background-size: cover; 
            background-position: center center; 
            width: 100%; 
            height: 100%; 
            opacity: 1; 
            visibility: inherit; 
            z-index: 20;
        }

        #leadership-details {
            font-size: 18px;
            font-family: 'Roboto', sans-serif;
        }
        
        #leadership-details a {
            transition: background-color 0.5s ease, border .5s ease;
            background-color: white;
        }
        #leadership-details a:hover {
            background-color: #FF6600; /* hover text color */
        }
        #leadership-details i {
            transition: color 0.5s ease;
            color: #085997;
            font-size: 1.09rem;
        }
        #leadership-details a:hover i{
            color: white; /* hover text color */
        }
    

         /* Animation styles */
         .fade-in {
            opacity: 0;
            animation: fadeInAnimation ease 2s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }
        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }
    </style>
     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'PUBLICATION'); ?> <?php $__env->endSlot(); ?>
    <section class="relative w-full h-full text-center lg:mb-0 overflow-hidden">
        <div class="relative px-5 py-24 lg:py-52 flex h-full w-full justify-start items-center z-41" 
        >
            <h1 class="text-3xl lg:text-4xl text-white font-semibold border-b-orange-800 fade-in" style="z-index: 42; font-family: 'Roboto', sans-serif; font-size:36px;">Conferences</h1>
        </div>
        <div class="slotholder background_3d_div" style="">
            <div class="tp-bgimg defaultimg background_3d_image_div" data-bgcolor="undefined" style="" src="<?php echo e(asset('assets/images/background/publications.jpg')); ?>"></div>
        </div>
    </section>
    <main id='leadership-details' class="w-full py-4 lg:py-10 px-8 lg:px-48 text-lg h-full overflow-hidden bg-gray-200">

        <div class="container mx-auto p-8">
            <div class="space-y-6">
                <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="space-y-1 bg-white pt-4 pl-6 shadow-sm shadow-slate-400  rounded-sm">
                    <div class="flex">
                        <div>

                        </div>
                        <div>
                            <div class="pb-3 text-gray-700" style="font-size: 17px;">                            
                                    <?php echo e($publication->title ?? ''); ?>

                            </div>
                            <?php if($publication->writer ?? ''): ?>
                            <?php
                                $writer = str_replace('Saifuzzaman, M.', '<span class="font-semibold">Saifuzzaman, M.</span>', $publication->writer);
                                $writer = str_replace('Saifuzzaman M.', '<span class="font-semibold">Saifuzzaman M.</span>', $writer);
                            ?>
                            <div class="line text-sm">
                                <?php echo $writer; ?>

                            </div>
                            <?php endif; ?>
                            <div class="text-sm pt-1 pb-2">
                                <span class="px-2 py-1 bg-indigo-500 text-slate-100 rounded-sm">Conference</span>
                                <span class="px-1"><?php echo e($publication->publisher ?? ''); ?>, <?php echo e($publication->year ?? ''); ?></span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="flex justify-end">
                            <a href="<?php echo e($publication->pdf ? asset($publication->pdf) : '#'); ?>" 
                                style="border-top:3px solid #FF6600;
                                border-right:.01rem solid gray;"
                                target="_blank" style="text-decoration:none;" class="text-blue-400  px-3 text-sm py-2">
                                <i class="fas fa-file-pdf"></i>
                            </a>
                            <a href="<?php echo e($publication->link ? asset($publication->link) : '#'); ?>"
                                style="border-top:3px solid #FF6600;"
                                target="_blank" style="text-decoration:none;" class="text-blue-400  px-2 text-sm py-2">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                    </div>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/publication_conferences.blade.php ENDPATH**/ ?>