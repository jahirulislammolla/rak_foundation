<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container mx-auto mt-5">
        <div class="flex flex-wrap">
            <div class="w-full">

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="bg-white shadow-md rounded-lg">
                    <div class="px-4 py-3 border-b text-lg font-semibold flex justify-between items-center">
                        <span>Role: <?php echo e($role->name); ?></span>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create role')): ?>
                        <a href="<?php echo e(url('roles')); ?>" class="btn btn-danger float-right text-white bg-red-500 hover:bg-red-600 px-4 py-2 rounded-lg">Back</a>
                        <?php endif; ?>
                    </div>
                    <div class="p-4">
                        <form action="<?php echo e(url('roles/'.$role->id.'/give-permissions')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="mb-4">
                                <?php $__errorArgs = ['permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <label for="" class="block mb-2 font-semibold">Permissions</label>

                                <div class="flex flex-wrap">
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="w-1/5 mb-2">
                                        <label class="inline-flex items-center">
                                            <input
                                                type="checkbox"
                                                name="permission[]"
                                                value="<?php echo e($permission->name); ?>"
                                                class="mr-2"
                                                <?php echo e(in_array($permission->id, $rolePermissions) ? 'checked':''); ?>

                                            />
                                            <?php echo e($permission->name); ?>

                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div>
                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\personal_website\resources\views/role-permission/role/add-permissions.blade.php ENDPATH**/ ?>