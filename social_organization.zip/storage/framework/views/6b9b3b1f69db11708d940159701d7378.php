<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        /* custom.css */
        .background_3d_div {
            position: absolute;
            top: 0px;
            left: 0px;
            z-index: 30;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            transform: translate3d(0px, 43.897px, 0px);
            visibility: inherit;
            opacity: 1;
            background-color: rgb(8, 25, 33);
        }

        .background_3d_image_div {
            background-repeat: no-repeat;
            background-image: url("<?php echo e(asset('assets/images/background/teaching.jpg')); ?>");
            background-size: cover;
            background-position: center center;
            width: 100%;
            height: 100%;
            opacity: 1;
            visibility: inherit;
            z-index: 20;
        }

        #teaching-bangladesh {
            font-size: 17px;
            font-family: 'Roboto', sans-serif;
        }

        #teaching-bangladesh a {
            transition: color 0.5s ease;
            color: rgba(56, 167, 8, 0.89);
        }

        #teaching-bangladesh a:hover {
            color: #FF6600;
            /* hover text color */
        }

        #teaching-canada {
            background-color: #067d7fe7;
            color: white;
            font-family: 'Roboto', sans-serif;
        }

        #teaching-canada a {
            transition: color 0.5s ease;
            color: rgb(42, 186, 243);
        }

        #teaching-canada a:hover {
            color: #FF6600;
            /* hover text color */
        }


        /* Animation styles */
        .fade-in {
            opacity: 0;
            animation: fadeInAnimation ease 2s;
            animation-iteration-count: 1;
            animation-fill-mode: forwards;
        }

        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }



        @keyframes text-animation {
            0% {
                opacity: 0;
                transform: translateY(-20px);
            }

            10%,
            90% {
                opacity: 1;
                transform: translateY(0);
            }

            100% {
                opacity: 0;
                transform: translateY(20px);
            }
        }

    </style>
     <?php $__env->slot('page_title', null, []); ?> <?php echo e($page_title ?? 'teaching'); ?> <?php $__env->endSlot(); ?>
    <section class="relative w-full h-full text-center lg:mb-0 overflow-hidden">
        <div class="relative px-5 py-24 lg:py-52 flex h-full w-full justify-start items-center z-41">
            <h1 class="text-3xl lg:text-4xl text-white font-semibold border-b-blue-800 fade-in" style="z-index: 42; font-family: 'Roboto', sans-serif; font-size:36px;">TEACHING</h1>
        </div>
        <div class="slotholder background_3d_div" style="">
            <div class="tp-bgimg defaultimg background_3d_image_div" data-bgcolor="undefined" style="" src="<?php echo e(asset('assets/images/background/profile.jpg')); ?>"></div>
        </div>
    </section>
    <!-- Academic Profile Section -->
    <?php
        $types = [
            1 => "Assistant Professor",
            2 => "Lecturer",
            3 => "Teaching Assistant",
            4 => "Course Instructor / Sessional Lecturer",
            5 => "Guest Lectures",
        ];
    ?>
    <main id='teaching-bangladesh' class="w-full py-2 lg:py-6 px-8 lg:px-48 text-lg h-full overflow-hidden bg-gray-200">
        <div class="space-y-6 animate-text">
            <div style="font-size: 16px;" class="space-y-6">
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="font-semibold text-2xl mt-6 mb-4"><?php echo e($type); ?></div>
                    <?php $__currentLoopData = $teachings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teaching): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == $teaching->type): ?>
                        <div>
                            <span class="bg-blue-500 text-white px-4 py-2 rounded-sm mr-4">
                                <?php echo e($teaching->title); ?>

                            </span>
                            <div class="bg-white ml-2 pt-3 pb-2 pl-3 shadow-sm shadow-slate-400  rounded-sm max-w-4xl" style="line-height: 1.8rem;">
                                <?php echo $teaching->content; ?>

                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>



        </div>
    </main>

    <script>
        const background = document.getElementById('background');

        function createLine() {
            const line = document.createElement('div');
            line.className = 'line';
            line.style.height = `${Math.random() * 100 + 50}px`;
            line.style.top = `${Math.random() * 100}vh`;
            line.style.left = `${Math.random() * 100}vw`;
            line.style.animationDuration = `${Math.random() * 10 + 5}s`;
            background.appendChild(line);

            setTimeout(() => {
                background.removeChild(line);
            }, 15000); // Ensure lines are removed after their animation ends
        }

        function createDot() {
            const dot = document.createElement('div');
            dot.className = 'dot';
            dot.style.top = `${Math.random() * 100}vh`;
            dot.style.left = `${Math.random() * 100}vw`;
            dot.style.animationDelay = `${Math.random() * 2}s`;
            background.appendChild(dot);

            setTimeout(() => {
                background.removeChild(dot);
            }, 2000); // Ensure dots are removed after their animation ends
        }

        function init() {
            for (let i = 0; i < 20; i++) {
                createLine();
                createDot();
            }

            setInterval(createLine, 1000);
            setInterval(createDot, 500);
        }

        window.onload = init;

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\personal_website\resources\views/teaching.blade.php ENDPATH**/ ?>